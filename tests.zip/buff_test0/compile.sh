#!/bin/sh
g++ -Wall -Werror -std=c++11 ../FileSystem.cpp -o fs
cp ../empty disk0
